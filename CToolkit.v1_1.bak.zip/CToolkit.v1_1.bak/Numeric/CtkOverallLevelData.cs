﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CToolkit.v1_1.Numeric
{
    public class CtkOverallLevelData
    {
        public double low;
        public double high;
        public double weight = 1;




    }
}
