﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CToolkit.v1_1
{
    [Serializable]
    [Guid("B18C6897-FC16-4B97-A678-FAA40240CD35")]
    public class CtkKeyValuePair<K, V>
    {



    }
}
