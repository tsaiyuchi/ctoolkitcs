﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CToolkit.v1_1._Worker
{
    public class ReadMe
    {
        /* [d20210211]
         * 建立一物件, 負責處理一 特定 領域/專長/作業 的事,
         * 此物件通常有自己的生命週, 與主物件的溝通方式 並 提供一些存取操作的方法.
         * 有點類似 Controller, 但 Controller 較像是在控制 商業邏輯層, 如何接軌 DB, UI 與 Model.
         * 而 Worker 的工作比較雜, 一個特定範圍的作業都是找它處理
         */


    }
}
