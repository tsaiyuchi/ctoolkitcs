﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CToolkit.v1_1.Net
{
    public enum EnumCtkConnectMode
    {
        Undefine,
        Listener,//=Passive
        Client,//=Active
    }
}
