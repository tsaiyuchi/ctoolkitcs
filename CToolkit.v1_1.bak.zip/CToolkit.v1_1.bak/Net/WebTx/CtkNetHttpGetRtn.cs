﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CToolkit.v1_1.Net.WebTx
{
    public class CtkNetHttpGetRtn<T>
    {
        public T Driver;
        public string Html;
    }
}
