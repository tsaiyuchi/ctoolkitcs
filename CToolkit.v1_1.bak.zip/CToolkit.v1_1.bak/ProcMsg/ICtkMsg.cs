﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CToolkit.v1_1.ProcMsg
{
    public interface ICtkMsg
    {
    }
}
