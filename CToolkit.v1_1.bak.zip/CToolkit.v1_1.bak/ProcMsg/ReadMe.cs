﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CToolkit.v1_1.ProcMsg
{
    public class ReadMe
    {
        /* [d20210211]
         * 建立以 message 概念為基本, 傳遞各類訊息的應用程式.
         * 所有的訊息都實作/繼承 某一 interface/class,
         * 並對物件建立訊息處理機制及方法.
         * 所有訊息都可被該專案的任一物件識別.
         */



    }
}
