﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CToolkit.v1_1.StateMachine
{
    public class ReadMe
    {

        /* [d20210211]
         * 應該要有幾種State Machine的型式
         * 1. 簡易版, 快速套用
         * 2. 完整版, 需配合實作
         * 3. 完整版2, 不同的狀態機表示方式
         * 但不急著現在做出來, 等有需要的時候再來思考怎麼做
         * 現在已有在專案上實作的經驗, 再來個1~2次經驗應該寫的出來
       */
    }
}
