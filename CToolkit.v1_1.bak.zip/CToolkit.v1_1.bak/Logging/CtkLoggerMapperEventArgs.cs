using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CToolkit.v1_1.Logging
{

    public class CtkLoggerMapperEventArgs : EventArgs
    {
        public string LoggerId;
        public CtkLogger Logger;


    }
}
