﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CToolkit.v1_1.TriggerDiagram
{
    public interface ICtkTdDiagram : ICtkTdBlock
    {
        /*[d20210531] 標註為 Diagram 無實際作用*/
        /*[d20210822] 基本上也不再使用*/

    }
}
