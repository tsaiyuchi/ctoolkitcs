﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CToolkit.v1_1
{
    [Serializable]
    public class CtkSerializableDictionary
    {


    }
}
