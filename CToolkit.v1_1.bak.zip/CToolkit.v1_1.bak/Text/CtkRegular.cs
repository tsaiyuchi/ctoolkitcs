﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CToolkit.v1_1.Text
{
    public class CtkRegular
    {
        //貨幣
        //^(-)?(\d+|,\d{3})+(\.\d{0,4})?$
    }
}
