﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CToolkit.v1_1.WinApiNative
{
    public enum CtkMdlInputType : int
    {
        Mouse = 0,
        Keyboard = 1,
        Hardware = 2
    }

}
